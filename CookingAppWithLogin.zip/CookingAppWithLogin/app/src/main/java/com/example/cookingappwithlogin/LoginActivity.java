package com.example.cookingappwithlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
EditText etxt_password,et_email;
Button btn_login;
DBHelper myDB;
//SharedPreferences sharedPreferences;
//private static final String Shared_Pref_Name="mypref";
  //  private static final String Key_Email="email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

       // sharedPreferences=getSharedPreferences(Shared_Pref_Name,MODE_PRIVATE);
        etxt_password= findViewById(R.id.etxt_password);
        et_email= findViewById(R.id.et_email);
        btn_login= findViewById(R.id.btn_login);
        myDB=new DBHelper(this);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // SharedPreferences.Editor editor=sharedPreferences.edit();

               String et_email1=et_email.getText().toString();

                String etxt_password1=etxt_password.getText().toString();
                if (et_email1.equals("")||etxt_password1.equals("")){
                    Toast.makeText(LoginActivity.this, "Please enter the credentials.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean result= myDB.checkuseremailPassword(et_email1,etxt_password1);
                    if (result==true){

                        Intent intent= new Intent(getApplicationContext(),HomeActivity.class);
/*
                        intent.putExtra("useremail",et_email1);
*/
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(LoginActivity.this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}