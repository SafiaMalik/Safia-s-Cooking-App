package com.example.cookingappwithlogin;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class LogoutFragment extends Fragment {

  private Button logout;


  public LogoutFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
      View view= inflater.inflate(R.layout.fragment_logout,container,false);

      logout= view.findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {

            final AlertDialog.Builder alertDialog=new AlertDialog.Builder(getContext()) ;
            alertDialog.setTitle("do u want to logout");
            alertDialog.setCancelable(false);
            alertDialog.setPositiveButton("yes", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialogInterface, int which) {

                Intent intent= new Intent(getContext(),LoginActivity.class);
                startActivity(intent);


              }
            });
            alertDialog.setNegativeButton("no", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialogInterface, int which) {
                dialogInterface.dismiss();
                Intent intent= new Intent(getContext(),HomeActivity.class);
                startActivity(intent);


              }
            });
            AlertDialog alertDialog1=alertDialog.create();
            alertDialog1.show();



          }
        });
return view;
    }
}