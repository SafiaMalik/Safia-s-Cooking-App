package com.example.cookingappwithlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
EditText et_name,et_password, et_repassword,et_email;
Button btn_register, btn_signin;
DBHelper myDB;
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[!@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                   // ".{8,20}" +               //at least 4 characters,upper limit
                    ".{8,}" +               //at least 4 characters
                    "$");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_name= findViewById(R.id.et_name);
        et_password= findViewById(R.id.et_password);
        et_repassword= findViewById(R.id.et_repassword);
        et_email= findViewById(R.id.et_email);
        btn_register= findViewById(R.id.btn_register);
        btn_signin= findViewById(R.id.btn_signin);
        myDB = new DBHelper(this);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String et_name1 = et_name.getText().toString();
                String et_password1 = et_password.getText().toString();
                String et_repassword1 = et_repassword.getText().toString();
                String et_email1 = et_email.getText().toString();



/*if(!Patterns.EMAIL_ADDRESS.matcher(et_email1).matches()){
                        Toast.makeText(MainActivity.this, "Enter valid email ", Toast.LENGTH_SHORT).show();
                    }

                if (et_name1.equals("") || et_password1.equals("") || et_repassword1.equals("") || et_email1.equals("")) {
                    Toast.makeText(MainActivity.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                } else {



                    if (et_password1.equals(et_repassword1)) {
                        Boolean usercheckResult = myDB.checkusername(et_name1);

                        if (usercheckResult == false){
                            Boolean regResult = myDB.insertData(et_name1, et_password1, et_email1);
                            if(regResult == true){
                                Toast.makeText(MainActivity.this, "Registration successful ", Toast.LENGTH_SHORT).show();
                                Intent intent= new Intent(getApplicationContext(),LoginActivity.class);
                                startActivity(intent);
                            }
                            else{Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();}

                        }
                        else{Toast.makeText(MainActivity.this, "User already exist.\n Please sign in.", Toast.LENGTH_SHORT).show();}

                    }
                    else{
                        Toast.makeText(MainActivity.this, "Password not matching", Toast.LENGTH_SHORT).show();
                    }
                }*/

                if (et_name1.equals("") || et_password1.equals("") || et_repassword1.equals("") || et_email1.equals("")) {
                    Toast.makeText(MainActivity.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                } else {
                    if(!Patterns.EMAIL_ADDRESS.matcher(et_email1).matches()){
                        Toast.makeText(MainActivity.this, "Enter valid email ", Toast.LENGTH_SHORT).show();
                    }else {
                        if (!PASSWORD_PATTERN.matcher(et_password1).matches()) {
                            Toast.makeText(MainActivity.this, "Password too weak ", Toast.LENGTH_SHORT).show();
                        }else{
                        if (et_password1.equals(et_repassword1)) {
                            Boolean usercheckResult = myDB.checkusername(et_name1);

                            if (usercheckResult == false) {
                                Boolean regResult = myDB.insertData(et_name1, et_password1, et_email1);
                                if (regResult == true) {
                                    Toast.makeText(MainActivity.this, "Registration successful ", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                                }

                            } else {
                                Toast.makeText(MainActivity.this, "User already exist.\n Please sign in.", Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            Toast.makeText(MainActivity.this, "Password not matching", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                }
































            }
            });


        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
            }
        });
    }




}